we are using langchain to talk to LLM
we are using mistral AI as a LLM
we are using virtual environment for our dependencies , it is called dsenv

we are using python version 3.12 to support langchain

